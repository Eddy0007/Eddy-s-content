var arr = ['foo'];
console.log(arr[0]);
var obj = { 0: 'foo' };
console.log(obj[0]);


// var questions=[
//   [ "What is 10+4?", "12","14","16","20", "B"],
//   [ "What is 15+4?", "12","14","19","20", "C"],
//   [ "What is 11+4?", "15","14","16","20", "A"],
//   [ "What is 10+7?", "12","17","16","20", "B"]
// ];
// function _(x){
//   return document.getElementById('x')
// }
function renderQuestion(){
  test=document.getElementById("test");
  if(position>=questions.length){
    document.getElementById("test").innerHTML="<h2> You got "+correct+" of "+questions.length+" questions correct.</h2>";
    document.getElementById("test_status").innerHTML="Test Completed";
    // position=0;
    // correct=0;
  }else{
    document.getElementById("test_status").innerHTML = "Question "+(position+1)+" of "+questions.length;
    question = questions[position][0];
    choiceA = questions[position][1];
    choiceB = questions[position][2];
    choiceC = questions[position][3];
    choiceD = questions[position][4];
    document.getElementById("test").innerHTML ="<h3>"+question+"</h3>";
    document.getElementById("test").innerHTML +="<input type='radio' name='choices' value='A'> "+choiceA+"<br>";
    document.getElementById("test").innerHTML +="<input type='radio' name='choices' value='B'> "+choiceB+"<br>";
    document.getElementById("test").innerHTML +="<input type='radio' name='choices' value='C'> "+choiceC+"<br>";
    document.getElementById("test").innerHTML +="<input type='radio' name='choices' value='D'> "+choiceD+"<br><br>";
    document.getElementById("test").innerHTML +="<button onclick='checkAnswer()'>Submit Answer</button>";
  }
}
function checkAnswer(){
  choices = document.getElementsByName("choices");
  for(var i=0; i<choices.length; i++){
    if(choices[i].checked){
      choice=choices[i].value;
    }
  }
  if(choice==questions[position][5]){
    correct++;
  }
  position++;
  renderQuestion();
}
window.addEventListener("load", renderQuestion, false);
