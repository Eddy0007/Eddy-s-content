var position=0, test, test_status, question, choice, choices, choiceA, choiceB, choiceC, choiceD, correct=0;
var questions=[
  [ "If a MA driver is considered more than _____ at fault in an accident, it will be noted on his or her driving record.", "25%","90%","50%","75%", "C"],
  [ "What does a yellow diamond sign a black + sing mean?", "A railroad crossing ahead","A side road ahead","A hospital ahead","A four-way intersection ahead", "D"],
  [ "On the highway, vehicles that are traveling slower than the rest of the traffic should use", "whichever lane has the least traffic","the left lane","the right lane","the center lane", "C"],
  [ "If your license was suspended in MA because your driving privileges had been suspended in another state, you must pay a fee of _____ to have your license reinstated.", "$750","$100","$500","$250", "B"],
  [ "question", "ans1", "ans2", "ans3", "ans4", "C"],
  [ "question", "ans1", "ans2", "ans3", "ans4", "C"],
  [ "question", "ans1", "ans2", "ans3", "ans4", "C"],
  [ "question", "ans1", "ans2", "ans3", "ans4", "C"],
  [ "question", "ans1", "ans2", "ans3", "ans4", "C"],
  [ "question", "ans1", "ans2", "ans3", "ans4", "C"]
];
